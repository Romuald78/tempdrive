#!/bin/bash
python3 Launcher.py

